#include <stdio.h> //Mahdi Soleimani 40223040
#include <math.h>
int main()
{
    float solver(float a, float b, float c, float *root1, float *root2);
    float a, b, c, root1, root2;
    printf("Please enter three numbers: ");
    scanf("%f %f %f", &a, &b, &c);
    if (a == 0 && b == 0)
        printf("Wrong entered!");
    else
    {
        solver(a, b, c, &root1, &root2);
        printf("The root1 is %f.\n", root1);
        printf("The root2 is %f.\n", root2);
    }
    return 0;
}
float solver(float a, float b, float c, float *root1, float *root2)
{
    float delta = (b * b - 4 * a * c);
    if (delta > 0)
    {
        *root1 = (-b + sqrt(delta)) / 2 * a;
        *root2 = (-b - sqrt(delta)) / 2 * a;
        printf("There are two roots.\n");
    }
    else if (delta == 0)
    {
        *root1 = *root2 = -b / (2 * a);
        printf("There is one root.\n");
    }
    else
        printf("This equation has no real roots!\n");
}
